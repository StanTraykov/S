#!/usr/bin/env bash
file=${1?"usage: $0 <dumbarb-output-file>"}
if ! [ -f "$file" ]; then
    echo "$file does not exist or is not a regular file."
    exit 1
fi

#wins
gawk '{
    tmv+=$9; mvmax=($9>mvmax?$9:mvmax);mvmin=($9<mvmin||mvmin==0?$9:mvmin)

    ++t; p1=$2; p2=$4; if($3=="W")p1W++; if($5=="W")p2W++; if($3=="B")p1B++; if($5=="W")p2B++;
    if($7==p1)p1wins++; if($7==p1&&$3=="W")p1winsW++; if($7==p1&&$3=="B")p1winsB++;
    if($7==p2)p2wins++; if($7==p2&&$5=="W")p2winsW++; if($7==p2&&$5=="B")p2winsB++;

    p1mv+=$10; p2mv+=$11; p1tt+=$12; p2tt+=$15;
    p1mtm=($14>p1mtm?$14:p1mtm); p2mtm=($17>p2mtm?$17:p2mtm);
    if($19 == p1) p1fvio++
    if($19 == p2) p2fvio++
    for(i=19; i<=NF; i+=2) {
        if($i == p1) p1tvio++
        if($i == p2) p2tvio++
    }
    if($19==p1 && $7==p1)
        p1BadWins++
    if($19==p2 && $7==p2)
        p2BadWins++
    }
    END{
        wi = length(p1)>length(p2)?length(p1):length(p2)
        margin = sprintf("%" wi "s", "")

        printf margin "                  %3d games, total moves %5d, avg %3d min %3d, max %3d\n",
            t, tmv, tmv/t, mvmin, mvmax;

        printf margin "    W   B      win       win as W    win as B  avg t/mv  max t/mv  viols\n";

        w=length(p1)>length(p2)?length(p1):length(p2)
        p_fmts = "%" wi "s: %3d %3d %3d [%4.1f%] %3d [%4.1f%] %3d [%4.1f%] %8.3fs %8.3fs %2d/%3d\n"

        printf p_fmts,
            p1, p1W, p1B, p1wins, 100*p1wins/t, p1winsW, 100*p1winsW/p1W, p1winsB, 100*p1winsB/p1B,
            p1tt/p1mv, p1mtm, p1fvio, p1tvio;

        printf p_fmts,
            p2, p2W, p2B, p2wins, 100*p2wins/t, p2winsW, 100*p2winsW/p2W, p2winsB, 100*p2winsB/p2B,
            p2tt/p2mv, p2mtm, p2fvio, p2tvio;

        printf "invalid wins, being the first to violate time: %s: %2d; %s: %2d\n",
            p1, p1BadWins, p2, p2BadWins;

        printf "total thinking times: %s: %5.2fh; %s: %5.2fh\n",
            p1, p1tt/3600, p2, p2tt/3600;
    }'  $file
