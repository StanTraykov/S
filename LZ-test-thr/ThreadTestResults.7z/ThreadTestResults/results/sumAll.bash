#!/usr/bin/env bash
rm -f SummaryAll.txt
for f in `ls *.log|sort -t T -gk 3`; do (bash summary.bash $f; echo) >> SummaryAll.txt; done
